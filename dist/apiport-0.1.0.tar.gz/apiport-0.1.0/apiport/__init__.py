"""
apiport - CLI tool for managing API secrets
"""

__version__ = "0.1.0"
